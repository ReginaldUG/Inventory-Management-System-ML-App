import json
import mysql.connector
import boto3
import csv
import io
from datetime import datetime

from mysql.connector import Error

# Initialize S3 client
s3_client = boto3.client('s3')

# RDS MySQL Configuration
DB_CONFIG = {
    "host": "database-1.cmvq2kr2ldmn.eu-west-1.rds.amazonaws.com",  #Database ARN
    "user": "admin",                                                #DB User name
    "password": "adminpassword",                                    #DB user password
    "database": "PredictionsDB"                                     #DB name
}

def lambda_handler(event, context):
    try:
        # Extract bucket name and file key from event
        bucket = event['Records'][0]['s3']['bucket']['name']
        csv_file = event['Records'][0]['s3']['object']['key']

        # Retrieve the CSV file from S3
        csv_file_obj = s3_client.get_object(Bucket=bucket, Key=csv_file)
        csv_content = csv_file_obj['Body'].read().decode('utf-8')

        # Parse CSV data
        csv_reader = csv.reader(io.StringIO(csv_content))
        next(csv_reader)  # Skip header row

        results = []
        for row in csv_reader:
            try:
                # Convert date format
                formatted_date = datetime.strptime(row[0], "%Y-%m-%d").strftime("%Y-%m-%d")
                #   Convert quantity to integer
                quantity = int(float(row[2])) 
                results.append((formatted_date, row[1], quantity))
            except ValueError as e:
                print(f"Skipping invalid date: {row[0]} - Error: {str(e)}")
                continue  # Skip invalid rows

        # Connect to MySQL database
        connection = mysql.connector.connect(**DB_CONFIG)
        cursor = connection.cursor()

        # Insert data into MySQL table
        insert_query = "INSERT INTO Predictions (Date, Article, Quantity) VALUES (%s, %s, %s)"
        cursor.executemany(insert_query, results)
        connection.commit()

        print(f"{cursor.rowcount} records inserted successfully into predictions table")

        cursor.close()
        connection.close()

        return {
            'statusCode': 200,
            'body': json.dumps(f"{cursor.rowcount} records inserted successfully")
        }

    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps('Error processing CSV')
        }
